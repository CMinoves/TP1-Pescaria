#include <GL/glew.h>
#include <GL/freeglut.h>
#include <stdio.h>
#include<time.h>
#include<SOIL/SOIL.h>
#include<QuadradoQueMove.c>
#define LARGURA_DO_MUNDO 100
#define ALTURA_DO_MUNDO 100
#define BOT_ALTURA 100
#define BOT_LARGURA 260
#define NUM_BOT 3
int abc;
GLuint fundao_textura;
GLuint novojogo_textura;
GLuint novojogo2_textura;
GLuint sair_textura;
GLuint sair2_textura;
GLuint ajuda_textura;
GLuint ajuda2_textura;
GLuint title_textura;
GLuint peixao_textura;
/*typedef struct {
  double posx;
  double posy;
  double tamx;
  double tamy;
  int tipo;
  int dir;
}objeto;
float W = 500;
float H = 650;*/
int op = 2;
objeto botao[NUM_BOT];
objeto fundao;
objeto title;
objeto peixao;
void desenhaMenu(void){
  glClear(GL_COLOR_BUFFER_BIT);
  //desenhando o fundao cabuloso
  glEnable(GL_TEXTURE_2D);
  glBindTexture(GL_TEXTURE_2D, fundao_textura);

  glBegin(GL_TRIANGLE_FAN);
  glColor3f(1,1,1);
    glTexCoord2f(0,0); glVertex3f(-(fundao.tamx)/2, -(fundao.tamy)/2, 0);
    glTexCoord2f(1,0); glVertex3f((fundao.tamx)/2, -(fundao.tamy)/2, 0);
    glTexCoord2f(1,1); glVertex3f((fundao.tamx)/2, (fundao.tamy)/2, 0);
    glTexCoord2f(0,1); glVertex3f(-(fundao.tamx)/2, (fundao.tamy)/2, 0);
  glEnd();
  glDisable(GL_TEXTURE_2D);

  //desenhando o peixao
  glPushMatrix();
  glTranslatef(peixao.posx,peixao.posy,0);
  glEnable(GL_TEXTURE_2D);
  glBindTexture(GL_TEXTURE_2D, peixao_textura);

  glBegin(GL_TRIANGLE_FAN);
  glColor3f(1,1,1);
    glTexCoord2f(0,0); glVertex3f(-(peixao.tamx)/2, -(peixao.tamy)/2, 0);
    glTexCoord2f(1,0); glVertex3f((peixao.tamx)/2, -(peixao.tamy)/2, 0);
    glTexCoord2f(1,1); glVertex3f((peixao.tamx)/2, (peixao.tamy)/2, 0);
    glTexCoord2f(0,1); glVertex3f(-(peixao.tamx)/2, (peixao.tamy)/2, 0);
  glEnd();
  glDisable(GL_TEXTURE_2D);
glPopMatrix();
  //desenhando o título

  glPushMatrix();
    glTranslatef(title.posx,title.posy,0);
    glColor3f(1,1,1);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, title_textura);
    glBegin(GL_TRIANGLE_FAN);
      glTexCoord2f(0,0);  glVertex3f(-(title.tamx)/2, -(title.tamy)/2, 0);
      glTexCoord2f(1,0);  glVertex3f((title.tamx)/2, -(title.tamy)/2, 0);
      glTexCoord2f(1,1);  glVertex3f((title.tamx)/2, (title.tamy)/2, 0);
      glTexCoord2f(0,1);  glVertex3f(-(title.tamx)/2, (title.tamy)/2, 0);
    glEnd();
    glDisable(GL_TEXTURE_2D);
  glPopMatrix();
  //desenhando os botões
  for(int x = 0;x<NUM_BOT;x++){
    glPushMatrix();
      glTranslatef(botao[x].posx,botao[x].posy,0);
      glEnable(GL_TEXTURE_2D);
      switch (x) {
        case 2:
          if(op==2){
            glBindTexture(GL_TEXTURE_2D, novojogo2_textura);
          }else{
            glBindTexture(GL_TEXTURE_2D, novojogo_textura);
          }
        break;

        case 1:
        if(op==1){
          glBindTexture(GL_TEXTURE_2D, ajuda2_textura);
        }else{
          glBindTexture(GL_TEXTURE_2D, ajuda_textura);
        }
        break;

        case 0:
        if(op==0){
          glBindTexture(GL_TEXTURE_2D, sair2_textura);
        }else{
          glBindTexture(GL_TEXTURE_2D, sair_textura);
        }
        break;
      }

      glBegin(GL_TRIANGLE_FAN);
      glTexCoord2f(0,0);  glVertex3f(-(botao[x].tamx)/2, -(botao[x].tamy)/2, 0);
      glTexCoord2f(1,0);  glVertex3f((botao[x].tamx)/2, -(botao[x].tamy)/2, 0);
      glTexCoord2f(1,1);  glVertex3f((botao[x].tamx)/2, (botao[x].tamy)/2, 0);
      glTexCoord2f(0,1);  glVertex3f(-(botao[x].tamx)/2, (botao[x].tamy)/2, 0);
      glEnd();
      glDisable(GL_TEXTURE_2D);
    glPopMatrix();
  }

  glutSwapBuffers();
}

void inicializatextura(){
  glClearColor(0.3,0.3,0.9,0);
  glEnable(GL_BLEND );
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,GL_NEAREST);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  fundao_textura = SOIL_load_OGL_texture("Sem fundo/Fundao.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  novojogo_textura = SOIL_load_OGL_texture("Sem fundo/Novo Jogo.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  novojogo2_textura = SOIL_load_OGL_texture("Sem fundo/Novo Jogo2.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  sair_textura = SOIL_load_OGL_texture("Sem fundo/Sair.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  sair2_textura = SOIL_load_OGL_texture("Sem fundo/Sair2.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  ajuda_textura = SOIL_load_OGL_texture("Sem fundo/Ajuda.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  title_textura = SOIL_load_OGL_texture("Sem fundo/Title.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  ajuda2_textura = SOIL_load_OGL_texture("Sem fundo/Ajuda2.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  peixao_textura = SOIL_load_OGL_texture("Sem fundo/Peixao.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
  if(peixao_textura==0){
    printf("Deu ruim no title\n");
  }
  if(ajuda2_textura==0){
    printf("Deu ruim na ajuda2\n");
  }
}

// Inicia algumas variáveis de estado
void inicializa(void)
{
    botao[0].tamx = BOT_LARGURA;
    botao[0].tamy = BOT_ALTURA;
    botao[0].posx = 0;
    botao[0].posy = -250;
    botao[1].tamx = BOT_LARGURA;
    botao[1].tamy = BOT_ALTURA;
    botao[1].posx = 0;
    botao[1].posy = -70;
    botao[2].tamx = BOT_LARGURA;
    botao[2].tamy = BOT_ALTURA;
    botao[2].posx = 0;
    botao[2].posy = 100;
    title.tamx = W;
    title.tamy = BOT_ALTURA+5;
    title.posx = 0;
    title.posy = 245;
    fundao.tamx = W;
    fundao.tamy = H+1000;
    fundao.posx = 0;
    fundao.posy = 0;
    peixao.tamx = 414;
    peixao.tamy = 500;
    peixao.posx = 0;
    peixao.posy = -50;
    inicializatextura();
    // cor para limpar a tela
    glClearColor(1, 1, 1, 0);      // branco
    //criando o anzol

}

// Callback de redimensionamento
void redimensiona(int w, int h)
{
    //   W = w;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-w/2, w/2, -h/2, h/2, -1, 1);
    glViewport(0, 0, w, h);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
  //  coisas[0].tamx = w;
  //  int w2 = h*aspectratio;
  //  glutReshapeWindow(500, 500);
}

// Callback de evento de teclado
void teclado(unsigned char key, int x, int y)
{
    switch(key)
    {
    case 'W':
    case 'w':
      if(op==2){
        op =0;
      }else{
        op++;
      }
    break;

    case 'S':
        case 's':
        if(op==0){
          op = 2;
        }else{
          op--;
        }
    break;

    case 13:
      switch (op) {
        case 0:
          exit(0);
        break;

        case 1:
          //ajuda
          desenhaMenu();
        break;

        case 2:
          //iniciar jogo
        abc = mainGame();
        break;
      }
    break;
    default:

    break;
    }
}



void atualizaobjetos(int i, int tipo){


}
void atualiza(){
  //printf("%i\n",op);
  glutPostRedisplay();
  glutTimerFunc(25, atualiza, 0);
}

// Rotina principal
int main(int argc, char **argv)
{

    srand(time(NULL));
    //fundao.posy =
    // Acordando o GLUT
    glutInit(&argc, argv);

    // Definindo a versão do OpenGL que vamos usar
    glutInitContextVersion(1, 1);
    glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);

    // Configuração inicial da janela do GLUT
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(W, H);
    // Abre a janela
    glutCreateWindow("Insira seu nome");
    inicializa();

    // Registra callbacks para alguns eventos
    glutDisplayFunc(desenhaMenu);
    glutReshapeFunc(redimensiona);
    glutKeyboardFunc(teclado);
    inicializa();
    glutTimerFunc(0, atualiza, 0);
  //

    // Entra em loop e nunca sai
    glutMainLoop();
    return 0;
}
